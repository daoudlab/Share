---
Module Name: PSFolderSize
Module Guid: 36ced1e4-028a-4687-8a7c-7ad4a4ca1df6
Download Help Link: {{ Update Download Link }}
Help Version: {{ Please enter version of help manually (X.X.X.X) format }}
Locale: en-US
---

# PSFolderSize Module
## Description
{{ Fill in the Description }}

## PSFolderSize Cmdlets
### [Get-FileReport](Get-FileReport.md)
{{ Fill in the Description }}

### [Get-FolderSize](Get-FolderSize.md)
{{ Fill in the Description }}

