# PSFolderSize
[![PSFolderSize](https://static1.squarespace.com/static/5644323de4b07810c0b6db7b/t/5bcc1e9e419202a53790e662/1540103847317/PSFolderSize.png)](https://www.gngrninja.com/script-ninja/2016/5/24/powershell-calculating-folder-sizes)

PSFolderSize is a [PowerShell](https://msdn.microsoft.com/powershell) based folder size calculation tool.
It provides an easy way to export the data as a csv, json, or xml file.

The GitHub repository is located [here](https://github.com/gngrninja/PSFolderSize).